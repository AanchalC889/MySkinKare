#ifndef DATABASE_H
#define DATABASE_H

#include <vector>
#include <string>
#include "Product.h"

class Database {
public:
    Database();
    void addProduct(const Product& product);
    Product getProduct(int id) const;
    void updateProduct(int id, const Product& product);
    void deleteProduct(int id);
    void saveToFile(const std::string& filename) const;

private:
    std::vector<Product> products;
};

#endif // DATABASE_H