#include "FileHandler.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <string>

void FileHandler::writeFile(const std::string& filename, const std::vector<std::string>& data) {
    std::ofstream outFile(filename);
    if (outFile.is_open()) {
        for (const auto& line : data) {
            outFile << line << std::endl;
        }
        outFile.close();
    } else {
        std::cerr << "Unable to open file for writing: " << filename << std::endl;
    }
}

std::vector<std::string> FileHandler::readFile(const std::string& filename) {
    std::vector<std::string> data;
    std::string line;
    std::ifstream inFile(filename);
    
    if (inFile.is_open()) {
        while (std::getline(inFile, line)) {
            data.push_back(line);
        }
        inFile.close();
    } else {
        std::cerr << "Unable to open file for reading: " << filename << std::endl;
    }
    
    return data;
}