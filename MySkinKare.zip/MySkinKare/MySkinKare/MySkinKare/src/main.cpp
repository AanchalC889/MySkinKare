#include <iostream>
#include "database/Database.h"
#include "auth/User.h"
#include "products/Product.h"
#include "utils/FileHandler.h"

int main() {
    // Initialize the database
    Database db;
    db.loadFromFile("products.txt");

    // User authentication
    User user;
    std::string username, password;

    std::cout << "Welcome to MySkinKare Shopping App!" << std::endl;
    std::cout << "Please log in." << std::endl;
    std::cout << "Username: ";
    std::cin >> username;
    std::cout << "Password: ";
    std::cin >> password;

    if (user.loginUser(username, password)) {
        std::cout << "Login successful!" << std::endl;

        // Display products
        std::cout << "Available products:" << std::endl;
        for (const auto& product : db.getProducts()) {
            std::cout << product.getName() << " - $" << product.getPrice() << std::endl;
        }
    } else {
        std::cout << "Invalid credentials. Please try again." << std::endl;
    }

    return 0;
}