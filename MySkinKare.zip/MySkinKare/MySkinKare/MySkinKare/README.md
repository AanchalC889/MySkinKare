# MySkinKare Shopping App

## Overview
MySkinKare is a simple shopping application designed for managing makeup products. It includes features for user authentication, product management, and basic database operations.

## Features
- User registration and login functionality
- Management of makeup products (add, update, delete)
- File handling for product data storage
- Unit tests to ensure functionality

## Project Structure
```
MySkinKare
├── src
│   ├── main.cpp
│   ├── database
│   │   ├── Database.cpp
│   │   └── Database.h
│   ├── auth
│   │   ├── User.cpp
│   │   └── User.h
│   ├── products
│   │   ├── Product.cpp
│   │   └── Product.h
│   └── utils
│       ├── FileHandler.cpp
│       └── FileHandler.h
├── include
│   └── headers.h
├── tests
│   └── unit_tests.cpp
├── CMakeLists.txt
└── README.md
```

## Setup Instructions
1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Use CMake to configure and build the project:
   ```bash
   mkdir build
   cd build
   cmake ..
   make
   ```
4. Run the application:
   ```bash
   ./MySkinKare
   ```

## Usage
- Register a new user to start using the application.
- Add, update, or delete makeup products as needed.
- View product details and manage your makeup inventory.

## Contributing
Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.