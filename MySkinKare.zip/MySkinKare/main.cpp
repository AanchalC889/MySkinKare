#include <iostream>
#include <string>
using namespace std;

class SkinCareProduct {
    string name;
    double price;
    
public:
    SkinCareProduct(string n, double p) : name(n), price(p) {}
    
    void display() {
        cout << "Product: " << name << "\nPrice: $" << price << endl;
    }
};

int main() {
    cout << "=== Skincare Product Manager ===" << endl;
    
    SkinCareProduct cleanser("Gentle Cleanser", 24.99);
    SkinCareProduct moisturizer("Daily Moisturizer", 29.99);
    
    cleanser.display();
    cout << "-------------------" << endl;
    moisturizer.display();
    
    return 0;
}