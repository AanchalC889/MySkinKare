#include "User.h"
#include <iostream>
#include <string>
#include <unordered_map>

class User {
public:
    User() {}

    bool registerUser(const std::string& username, const std::string& password) {
        if (users.find(username) != users.end()) {
            std::cout << "User already exists!" << std::endl;
            return false;
        }
        users[username] = password;
        std::cout << "User registered successfully!" << std::endl;
        return true;
    }

    bool loginUser(const std::string& username, const std::string& password) {
        auto it = users.find(username);
        if (it != users.end() && it->second == password) {
            std::cout << "Login successful!" << std::endl;
            return true;
        }
        std::cout << "Invalid username or password!" << std::endl;
        return false;
    }

private:
    std::unordered_map<std::string, std::string> users;
};