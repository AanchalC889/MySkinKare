#ifndef FILE_HANDLER_H
#define FILE_HANDLER_H

#include <string>

class FileHandler {
public:
    void readFile(const std::string& filename);
    void writeFile(const std::string& filename, const std::string& data);
};

#endif // FILE_HANDLER_H