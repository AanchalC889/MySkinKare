#include <iostream>
#include <cassert>
#include "../src/database/Database.h"
#include "../src/auth/User.h"
#include "../src/products/Product.h"

void testAddProduct() {
    Database db;
    Product product("Lipstick", 19.99);
    db.addProduct(product);
    assert(db.getProduct("Lipstick").getPrice() == 19.99);
}

void testUserRegistration() {
    User user;
    assert(user.registerUser("testuser", "password123") == true);
    assert(user.loginUser("testuser", "password123") == true);
}

void testGetProductDetails() {
    Product product("Foundation", 29.99);
    assert(product.getName() == "Foundation");
    assert(product.getPrice() == 29.99);
}

int main() {
    testAddProduct();
    testUserRegistration();
    testGetProductDetails();
    
    std::cout << "All tests passed!" << std::endl;
    return 0;
}