#include "Database.h"
#include <iostream>
#include <fstream>
#include <vector>

class Product {
public:
    std::string name;
    double price;

    Product(std::string n, double p) : name(n), price(p) {}
};

class Database {
private:
    std::vector<Product> products;

public:
    void addProduct(const std::string& name, double price) {
        products.emplace_back(name, price);
    }

    Product getProduct(int index) {
        if (index >= 0 && index < products.size()) {
            return products[index];
        }
        throw std::out_of_range("Product index out of range");
    }

    void saveToFile(const std::string& filename) {
        std::ofstream file(filename);
        if (file.is_open()) {
            for (const auto& product : products) {
                file << product.name << "," << product.price << "\n";
            }
            file.close();
        } else {
            std::cerr << "Unable to open file for writing." << std::endl;
        }
    }

    void loadFromFile(const std::string& filename) {
        std::ifstream file(filename);
        std::string line;
        while (std::getline(file, line)) {
            size_t commaPos = line.find(',');
            if (commaPos != std::string::npos) {
                std::string name = line.substr(0, commaPos);
                double price = std::stod(line.substr(commaPos + 1));
                addProduct(name, price);
            }
        }
        file.close();
    }
};